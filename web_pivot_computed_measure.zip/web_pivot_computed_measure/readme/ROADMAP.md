1.  Add support to define a style for a computed measure (ex. colored)
2.  Use t-model to data-binding instead of jquery selectors
